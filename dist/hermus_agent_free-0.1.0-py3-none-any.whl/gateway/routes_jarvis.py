"""Read-only control-plane data and honest Navigator operations for JARVIS.

This router exposes the product-facing Nexus contract while retaining the
existing runtime endpoints for compatibility. Nexus is the interaction layer;
queue/run services remain the execution layer.
"""

from __future__ import annotations

import asyncio
import ipaddress
import socket
import time
from urllib.parse import urlparse

from fastapi import APIRouter
from fastapi.responses import JSONResponse

from core.nexus.service import nexus
from core.orchestrator import orchestrator
from core.run_events import run_bus
from gateway.probe_cache import ProbeCache, fresh_requested

router = APIRouter()
_STARTED = time.monotonic()


def _active_count(rows: list[dict]) -> int:
    return sum(1 for row in rows if row.get("status") in {"queued", "running"})


#: ``mission_capability_gate`` asks the selected provider whether this model can
#: actually run a mission. That round trip measured 8.1 s and was the entire
#: latency of this endpoint (queue, agents, tools and the GPU sample together cost
#: 0.3 s). Its answer only changes when the model does, so it is cached while
#: everything else here stays live — caching the whole status instead would have
#: made the queue counts lie.
CAPABILITY_GATE = ProbeCache("jarvis.capability_gate", ttl=30.0)


@router.get("/api/jarvis/status")
async def jarvis_status(fresh: str = ""):
    return await _jarvis_status_probe(fresh=fresh_requested(fresh))


async def _jarvis_status_probe(fresh: bool = False):
    from core.agent_manager import agent_manager
    from core.artifact_manager import artifact_manager
    from core.computer.resources import get_resource_monitor
    from core.config import config
    from core.model_capabilities import mission_capability_gate
    from core.providers import list_providers
    from core.tool_registry import tool_registry
    from gateway.channels import get_channel_status, get_discord_token, get_telegram_token
    from gateway.queue import job_queue

    queue = job_queue.status()
    jobs = job_queue.list_jobs(limit=100)
    runs = run_bus.runs()[-100:]
    agents = agent_manager.list()
    tools = tool_registry.list_tools()
    channels = get_channel_status()
    artifacts = artifact_manager.list_artifacts()
    model_ref = str(getattr(config, "model", "") or "")
    capability = await CAPABILITY_GATE.get(lambda: asyncio.to_thread(mission_capability_gate, model_ref), fresh=fresh)
    telemetry = await asyncio.to_thread(get_resource_monitor().sample)
    providers = list_providers()
    return {
        "gateway": {"reachable": True, "version": "2.2-free-architecture", "uptime_seconds": int(time.monotonic() - _STARTED)},
        "queue": queue,
        "counts": {
            "active_jobs": _active_count(jobs),
            "active_runs": _active_count(runs),
            "tools": int(tools.get("count", len(tools.get("tools", [])))),
            "agents": len(agents),
            "artifacts": len(artifacts),
        },
        "runs": runs,
        "jobs": jobs,
        "channels": {
            "runtime": channels,
            "telegram_configured": bool(get_telegram_token()),
            "discord_configured": bool(get_discord_token()),
        },
        "model": capability.to_dict() if hasattr(capability, "to_dict") else capability,
        "providers": providers,
        "telemetry": telemetry,
    }


def _validate_public_url(value: str) -> tuple[str | None, str | None]:
    try:
        parsed = urlparse(value)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            return None, "Only absolute http:// or https:// URLs are supported"
        for info in socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80)):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
                return None, "Private, loopback, link-local and reserved addresses are not allowed"
        return value, None
    except Exception as exc:
        return None, f"URL validation failed: {exc}"


@router.post("/navigator/fetch")
async def navigator_fetch(payload: dict | None = None):
    payload = payload or {}
    url, error = await asyncio.to_thread(_validate_public_url, str(payload.get("url") or "").strip())
    if error:
        return JSONResponse({"success": False, "error": error}, status_code=400)
    from tools.browser import browser_extract, browser_navigate

    result = await asyncio.to_thread(browser_navigate, url)
    if not result.get("success"):
        return JSONResponse(result, status_code=503)
    extracted = await asyncio.to_thread(browser_extract, "body")
    if not extracted.get("success"):
        return JSONResponse(
            {**result, "success": False, "error": extracted.get("error", "Page loaded but extraction failed")}, status_code=502
        )
    return {
        "success": True,
        "url": result.get("url", url),
        "title": result.get("title") or "",
        "content_length": result.get("content_length"),
        "text": str(extracted.get("text") or "")[:20000],
        "retrieval": "playwright",
    }


# ---------------------------------------------------------------- Nexus API
# The dashboard consumes this product-level contract. It does not need to know
# how queues, agents, memory, approvals or tools are implemented internally.
@router.get("/api/nexus/state")
async def nexus_state(user_id: str = "default"):
    return orchestrator.state(user_id=user_id)


@router.post("/api/nexus/command")
async def nexus_command(payload: dict | None = None):
    payload = payload or {}
    result = orchestrator.submit(
        str(payload.get("text") or ""),
        user_id=str(payload.get("user_id") or "default"),
        session_id=str(payload.get("session_id") or "") or None,
        platform=str(payload.get("channel") or payload.get("platform") or "nexus"),
        mode=str(payload.get("mode") or "chat"),
        prefer=str(payload.get("prefer") or "") or None,
        priority=int(payload.get("priority") or 0),
    )
    return JSONResponse(result.to_dict(), status_code=202 if result.accepted else 400)


@router.get("/api/nexus/missions/{mission_id}")
async def nexus_mission(mission_id: str):
    mission = nexus.mission(mission_id)
    if mission is None:
        return JSONResponse({"error": "mission not found", "mission_id": mission_id}, status_code=404)
    return {"mission": mission}


@router.post("/api/nexus/runs/{run_id}/cancel")
async def nexus_cancel(run_id: str):
    ok = orchestrator.cancel(run_id)
    return JSONResponse({"ok": ok, "run_id": run_id}, status_code=200 if ok else 404)


@router.post("/api/nexus/runs/{run_id}/steer")
async def nexus_steer(run_id: str, payload: dict | None = None):
    payload = payload or {}
    text = str(payload.get("text") or "").strip()
    if not text:
        return JSONResponse({"ok": False, "error": "text is required"}, status_code=400)
    ok = orchestrator.steer(run_id, text)
    return JSONResponse({"ok": ok, "run_id": run_id}, status_code=200 if ok else 404)


@router.get("/api/nexus/runs/{run_id}")
async def nexus_run(run_id: str, after: int = 0):
    run = run_bus.get(run_id)
    if run is None:
        return JSONResponse({"error": "run not found", "run_id": run_id}, status_code=404)
    return {"run": run.to_dict(), "events": run_bus.history(run_id, after=after)}
